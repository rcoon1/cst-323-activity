package com.gcu.exception;


public class DuplicateRecordException  extends Exception
{
	public DuplicateRecordException(String msg) {
		super(msg);
	}
}
