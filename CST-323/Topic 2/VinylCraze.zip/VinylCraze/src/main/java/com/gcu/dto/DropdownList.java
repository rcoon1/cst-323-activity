package com.gcu.dto;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
